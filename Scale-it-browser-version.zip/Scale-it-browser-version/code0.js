gdjs.Untitled_32scene5Code = {};
gdjs.Untitled_32scene5Code.localVariables = [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite11Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite11Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite12Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite12Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite13Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite13Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite14Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite14Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite2Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite2Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects2= [];
gdjs.Untitled_32scene5Code.GDLevel_9595One_9595text_9595_9595_9595Objects1= [];
gdjs.Untitled_32scene5Code.GDLevel_9595One_9595text_9595_9595_9595Objects2= [];
gdjs.Untitled_32scene5Code.GDNewSpriteObjects1= [];
gdjs.Untitled_32scene5Code.GDNewSpriteObjects2= [];
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595or_9595DashObjects1= [];
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595or_9595DashObjects2= [];
gdjs.Untitled_32scene5Code.GDMoveObjects1= [];
gdjs.Untitled_32scene5Code.GDMoveObjects2= [];
gdjs.Untitled_32scene5Code.GDJumpObjects1= [];
gdjs.Untitled_32scene5Code.GDJumpObjects2= [];
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595and_9595DashObjects1= [];
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595and_9595DashObjects2= [];
gdjs.Untitled_32scene5Code.GDDouble_9595JumpObjects1= [];
gdjs.Untitled_32scene5Code.GDDouble_9595JumpObjects2= [];
gdjs.Untitled_32scene5Code.GDIceObjects1= [];
gdjs.Untitled_32scene5Code.GDIceObjects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite3Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite3Objects2= [];
gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects1= [];
gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite4Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite4Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite21Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite21Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite22Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite22Objects2= [];
gdjs.Untitled_32scene5Code.GDNew3DBoxObjects1= [];
gdjs.Untitled_32scene5Code.GDNew3DBoxObjects2= [];
gdjs.Untitled_32scene5Code.GDNew3DBox2Objects1= [];
gdjs.Untitled_32scene5Code.GDNew3DBox2Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTextObjects1= [];
gdjs.Untitled_32scene5Code.GDNewTextObjects2= [];
gdjs.Untitled_32scene5Code.GDNewSprite5Objects1= [];
gdjs.Untitled_32scene5Code.GDNewSprite5Objects2= [];
gdjs.Untitled_32scene5Code.GDMonkeyObjects1= [];
gdjs.Untitled_32scene5Code.GDMonkeyObjects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite10Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite10Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite9Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite9Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite8Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite8Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite7Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite7Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite6Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite6Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite5Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite5Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite4Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite4Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite3Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite3Objects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32scene5Code.GDMain_9595Menu_9595MonkeyObjects1= [];
gdjs.Untitled_32scene5Code.GDMain_9595Menu_9595MonkeyObjects2= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1= [];
gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects2= [];


gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32scene5Code.GDNewSprite2Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite16Objects1Objects = Hashtable.newFrom({"NewTiledSprite16": gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite20Objects1Objects = Hashtable.newFrom({"NewTiledSprite20": gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNew3DBox2Objects1Objects = Hashtable.newFrom({"New3DBox2": gdjs.Untitled_32scene5Code.GDNew3DBox2Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32scene5Code.GDNewSpriteObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.Untitled_32scene5Code.GDNewSprite4Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.Untitled_32scene5Code.GDNewSprite3Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects = Hashtable.newFrom({"NewTiledSprite15": gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects = Hashtable.newFrom({"NewTiledSprite15": gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32scene5Code.GDMonkeyObjects1});
gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects = Hashtable.newFrom({"NewTiledSprite15": gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1});
gdjs.Untitled_32scene5Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32scene5Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.Untitled_32scene5Code.GDNewSprite4Objects1);
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewSprite3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewSprite4Objects1[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11388524);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(3000);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dash");
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("Animation").setAnimationName("Dash");
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dash") >= 0.5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(450);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene5Code.GDMonkeyObjects1[k] = gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dash") >= 1;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32scene5Code.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene5Code.GDMonkeyObjects1[k] = gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene5Code.GDMonkeyObjects1[k] = gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite17"), gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite18"), gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects1);
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 9);
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 3);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite19"), gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1);
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1[i].setXOffset(gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1[i].getXOffset() - (30));
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1[i].setYOffset(gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1[i].getYOffset() - (30));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite16"), gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite16Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite20"), gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite20Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("New3DBox2"), gdjs.Untitled_32scene5Code.GDNew3DBox2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNew3DBox2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32scene5Code.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene5");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.Untitled_32scene5Code.GDNewSprite4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewSprite4Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32scene5Code.GDNewSprite3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Different_types_of_goals_"), gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects1);
/* Reuse gdjs.Untitled_32scene5Code.GDNewSprite3Objects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDNewSprite3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite15"), gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setDeceleration(100);
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setAcceleration(3000);
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(900);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite15"), gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Ice") <= 3;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDMonkeyObjects1 */
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Ice");
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(450);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getY() >= 3000 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32scene5Code.GDMonkeyObjects1[k] = gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene5", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32scene5Code.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite15"), gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDMonkeyObjects1Objects, gdjs.Untitled_32scene5Code.mapOfGDgdjs_9546Untitled_959532scene5Code_9546GDNewTiledSprite15Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32scene5Code.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setDeceleration(3000);
}
}{for(var i = 0, len = gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32scene5Code.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setAcceleration(1500);
}
}}

}


};

gdjs.Untitled_32scene5Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene5Code.GDNewTiledSprite11Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite11Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite17Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite12Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite12Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite13Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite13Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite14Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite14Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite15Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite16Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite18Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDLevel_9595One_9595text_9595_9595_9595Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDLevel_9595One_9595text_9595_9595_9595Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595or_9595DashObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595or_9595DashObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDMoveObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDMoveObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDJumpObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDJumpObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595and_9595DashObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595Jump_9595and_9595DashObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595JumpObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDDouble_9595JumpObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDIceObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDIceObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDDifferent_9595types_9595of_9595goals_9595Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite20Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite21Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite21Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite22Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite22Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNew3DBoxObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNew3DBoxObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNew3DBox2Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNew3DBox2Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTextObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTextObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDMonkeyObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDMonkeyObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite10Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite10Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite9Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite9Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite8Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite8Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite7Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite7Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite6Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite6Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite5Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite5Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32scene5Code.GDMain_9595Menu_9595MonkeyObjects1.length = 0;
gdjs.Untitled_32scene5Code.GDMain_9595Menu_9595MonkeyObjects2.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects1.length = 0;
gdjs.Untitled_32scene5Code.GDNewTiledSprite19Objects2.length = 0;

gdjs.Untitled_32scene5Code.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32scene5Code'] = gdjs.Untitled_32scene5Code;
