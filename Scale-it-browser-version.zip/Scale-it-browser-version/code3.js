gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite11Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite11Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite12Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite12Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite13Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite13Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite14Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite14Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite15Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite15Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects2= [];
gdjs.Untitled_32sceneCode.GDLevel_9595One_9595text_9595_9595_9595Objects1= [];
gdjs.Untitled_32sceneCode.GDLevel_9595One_9595text_9595_9595_9595Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595or_9595DashObjects1= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595or_9595DashObjects2= [];
gdjs.Untitled_32sceneCode.GDMoveObjects1= [];
gdjs.Untitled_32sceneCode.GDMoveObjects2= [];
gdjs.Untitled_32sceneCode.GDJumpObjects1= [];
gdjs.Untitled_32sceneCode.GDJumpObjects2= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595and_9595DashObjects1= [];
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595and_9595DashObjects2= [];
gdjs.Untitled_32sceneCode.GDDouble_9595JumpObjects1= [];
gdjs.Untitled_32sceneCode.GDDouble_9595JumpObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite20Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite20Objects2= [];
gdjs.Untitled_32sceneCode.GDMonkeyObjects1= [];
gdjs.Untitled_32sceneCode.GDMonkeyObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite10Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite10Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite9Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite9Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite8Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite8Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite7Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite7Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite6Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite6Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDMain_9595Menu_9595MonkeyObjects1= [];
gdjs.Untitled_32sceneCode.GDMain_9595Menu_9595MonkeyObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32sceneCode.GDMonkeyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32sceneCode.GDNewSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32sceneCode.GDMonkeyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewTiledSprite16Objects1Objects = Hashtable.newFrom({"NewTiledSprite16": gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects = Hashtable.newFrom({"Monkey": gdjs.Untitled_32sceneCode.GDMonkeyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11754380);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(3000);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "dash");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("Animation").setAnimationName("Dash");
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dash") >= 0.5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(450);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMonkeyObjects1[k] = gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "dash") >= 1;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32sceneCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMonkeyObjects1[k] = gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDMonkeyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMonkeyObjects1[k] = gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite17"), gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite18"), gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 9);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 3);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite19"), gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1[i].setXOffset(gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1[i].getXOffset() - (30));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1[i].setYOffset(gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1[i].getYOffset() - (30));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite16"), gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewTiledSprite16Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDMonkeyObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Untitled scene3");
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monkey"), gdjs.Untitled_32sceneCode.GDMonkeyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i].getY() >= 3000 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDMonkeyObjects1[k] = gdjs.Untitled_32sceneCode.GDMonkeyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewTiledSprite11Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite11Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite17Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite12Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite12Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite13Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite13Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite14Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite14Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite15Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite15Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite16Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite18Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDLevel_9595One_9595text_9595_9595_9595Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDLevel_9595One_9595text_9595_9595_9595Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595or_9595DashObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595or_9595DashObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDMoveObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMoveObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDJumpObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDJumpObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595and_9595DashObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595Jump_9595and_9595DashObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595JumpObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDouble_9595JumpObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite20Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite20Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMonkeyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMonkeyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite10Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite10Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite9Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite9Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite8Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite8Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite7Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDMain_9595Menu_9595MonkeyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDMain_9595Menu_9595MonkeyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSprite19Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
